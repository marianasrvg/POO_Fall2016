package com.game.shift;

import com.game.shift.graficos.Background;

public class Shift {
	public static void main(String[] args){
	Background game = new Background();
	game.start();
	}
}
